const http = require('http');

const requestListener = function (req, res) {
    res.writeHead(200);
    res.end(`Hello, from web-app2`);
}

http.createServer(requestListener).listen(8080);
console.log('web server is listening');
